/* Secret-room gold light. Scroll progress only — no animation-timeline.
   iPhone Safari does not implement view timelines, so a timeline-only film
   would stay on the first line. */
(function () {
  function clamp(value, min, max) {
    return Math.min(max, Math.max(min, value));
  }

  function sweepPose(progress, kind) {
    var u = clamp(progress, 0, 1);
    if (kind === "orb") {
      var raw = u < 0.62 ? -0.15 + Math.pow(u / 0.62, 0.78) * 1.3 : 1.15 + (u - 0.62) * 0.08;
      var travel = Math.min(raw, 0.9);
      var bloomIn = Math.sin(Math.min(1, u / 0.2) * Math.PI * 0.5);
      var bloom = u < 0.82 ? bloomIn : bloomIn * (1 - ((u - 0.82) / 0.18) * 0.28);
      var glow = 0.12 + bloom * 0.88;
      return { travel: travel, bloom: bloom, glow: glow };
    }
    return {
      travel: -0.06 + u * 1.12,
      bloom: 0.42 + Math.sin(u * Math.PI) * 0.58,
      glow: 0.28 + Math.sin(u * Math.PI) * 0.55
    };
  }

  function beatRange(index, count, frontLoaded) {
    if (frontLoaded && count === 3) {
      var door = [
        [0, 0.1],
        [0.045, 0.5],
        [0.4, 1]
      ];
      return door[index] || [0, 1];
    }
    var span = 1 / Math.max(count, 1);
    var overlap = span * 0.22;
    var from = Math.max(0, index * span - (index === 0 ? 0 : overlap * 0.5));
    var to = Math.min(1, (index + 1) * span + (index === count - 1 ? 0 : overlap));
    return [from, to];
  }

  function beatPose(index, count, progress, frontLoaded) {
    var range = beatRange(index, count, frontLoaded);
    var span = Math.max(range[1] - range[0], 0.0001);
    var local = (progress - range[0]) / span;
    var fadeIn = index === 0 ? 0 : frontLoaded ? 0.16 : 0.18;
    var fadeOut = index === count - 1 ? 0 : frontLoaded ? 0.34 : 0.22;
    if (local <= 0) {
      if (index === 0) return { opacity: 1, y: 0 };
      return { opacity: 0, y: 16 };
    }
    if (local >= 1) {
      if (index === count - 1) return { opacity: 1, y: 0 };
      return { opacity: 0, y: -12 };
    }
    if (local < fadeIn) {
      var tIn = local / fadeIn;
      return { opacity: tIn, y: 16 * (1 - tIn) };
    }
    if (fadeOut > 0 && local > 1 - fadeOut) {
      var tOut = (local - (1 - fadeOut)) / fadeOut;
      return { opacity: 1 - tOut, y: -12 * tOut };
    }
    return { opacity: 1, y: 0 };
  }

  function clipFace(ctx, x, y, w, h, round) {
    ctx.beginPath();
    if (round) {
      ctx.arc(x + w / 2, y + h / 2, Math.min(w, h) / 2, 0, Math.PI * 2);
    } else if (typeof ctx.roundRect === "function") {
      ctx.roundRect(x, y, w, h, Math.min(w, h) * 0.08);
    } else {
      ctx.rect(x, y, w, h);
    }
    ctx.clip();
  }

  function drawSheen(ctx, width, height, progress, round, kind) {
    var pose = sweepPose(progress, kind);
    ctx.clearRect(0, 0, width, height);
    ctx.save();
    clipFace(ctx, 0, 0, width, height, round);
    var cx = width / 2;
    var cy = height / 2;
    var x = pose.travel * width;
    var ribbon = Math.max(8, width * (0.055 + pose.bloom * 0.14));
    var wash = ribbon * (2.2 + pose.bloom * 1.6);
    ctx.translate(cx, cy);
    ctx.rotate(-0.28);
    ctx.translate(-cx, -cy);
    var washGrad = ctx.createLinearGradient(x - wash, 0, x + wash, 0);
    washGrad.addColorStop(0, "rgba(201, 160, 64, 0)");
    washGrad.addColorStop(0.38, "rgba(201, 160, 64, " + (0.28 + pose.bloom * 0.22) + ")");
    washGrad.addColorStop(0.5, "rgba(243, 224, 168, " + (0.55 + pose.bloom * 0.3) + ")");
    washGrad.addColorStop(0.62, "rgba(201, 160, 64, " + (0.28 + pose.bloom * 0.22) + ")");
    washGrad.addColorStop(1, "rgba(201, 160, 64, 0)");
    ctx.fillStyle = washGrad;
    ctx.fillRect(x - wash, -height, wash * 2, height * 3);
    var core = ctx.createLinearGradient(x - ribbon, 0, x + ribbon, 0);
    core.addColorStop(0, "rgba(255, 248, 220, 0)");
    core.addColorStop(0.35, "rgba(243, 224, 168, " + (0.2 + pose.bloom * 0.15) + ")");
    core.addColorStop(0.5, "rgba(255, 252, 244, " + (0.62 + pose.bloom * 0.22) + ")");
    core.addColorStop(0.65, "rgba(243, 224, 168, " + (0.2 + pose.bloom * 0.15) + ")");
    core.addColorStop(1, "rgba(255, 248, 220, 0)");
    ctx.fillStyle = core;
    ctx.fillRect(x - ribbon, -height, ribbon * 2, height * 3);
    ctx.restore();
  }

  function drawField(ctx, width, height, face, progress, dpr, kind) {
    var pose = sweepPose(progress, kind);
    ctx.clearRect(0, 0, width, height);
    var fx = (face.x + face.w * pose.travel) * dpr;
    var fy = (face.y + face.h * 0.46) * dpr;
    var radius = Math.max(face.w, face.h) * dpr * (0.72 + pose.bloom * 0.55);
    var glow = ctx.createRadialGradient(fx, fy, radius * 0.04, fx, fy, radius);
    glow.addColorStop(0, "rgba(255, 246, 220, " + (0.16 + pose.bloom * 0.22) + ")");
    glow.addColorStop(0.22, "rgba(243, 224, 168, " + (0.12 + pose.bloom * 0.12) + ")");
    glow.addColorStop(0.55, "rgba(201, 160, 64, " + (0.05 + pose.bloom * 0.05) + ")");
    glow.addColorStop(1, "rgba(201, 160, 64, 0)");
    ctx.fillStyle = glow;
    ctx.fillRect(0, 0, width, height);
  }

  function resizeCanvas(canvas, cssWidth, cssHeight) {
    var dpr = Math.min(window.devicePixelRatio || 1, 2);
    var width = Math.max(1, Math.round(cssWidth * dpr));
    var height = Math.max(1, Math.round(cssHeight * dpr));
    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
    }
    return dpr;
  }

  function kindOf(chapter) {
    if (chapter.dataset.kind === "product" || chapter.dataset.kind === "mark") return chapter.dataset.kind;
    return "orb";
  }

  function paintChapter(chapter, progress) {
    var stage = chapter.querySelector(".sf-stage");
    var face = chapter.querySelector("[data-sf-face]");
    var field = chapter.querySelector(".sf-field");
    var sheen = chapter.querySelector(".sf-sheen");
    if (!stage || !face || !field || !sheen) return;
    var stageRect = stage.getBoundingClientRect();
    var faceRect = face.getBoundingClientRect();
    var dpr = resizeCanvas(field, stageRect.width, stageRect.height);
    resizeCanvas(sheen, faceRect.width, faceRect.height);
    var round = face.dataset.sfFace === "orb";
    var box = {
      x: faceRect.left - stageRect.left,
      y: faceRect.top - stageRect.top,
      w: faceRect.width,
      h: faceRect.height,
      round: round
    };
    var kind = kindOf(chapter);
    var fieldCtx = field.getContext("2d");
    var sheenCtx = sheen.getContext("2d");
    if (fieldCtx) drawField(fieldCtx, field.width, field.height, box, progress, dpr, kind);
    if (sheenCtx) drawSheen(sheenCtx, sheen.width, sheen.height, progress, round, kind);
    var pose = sweepPose(progress, kind);
    stage.style.setProperty("--travel", pose.travel.toFixed(3));
    stage.style.setProperty("--bloom", pose.bloom.toFixed(3));
    stage.style.setProperty("--glow", pose.glow.toFixed(3));
    chapter.dataset.sfProgress = progress.toFixed(3);
    var frontLoaded = chapter.dataset.chapter === "door";
    var beats = Array.prototype.slice.call(chapter.querySelectorAll("[data-sf-beat]"));
    var best = 0;
    var bestOpacity = -1;
    beats.forEach(function (beat) {
      var index = Number(beat.getAttribute("data-sf-beat") || 0);
      var line = beatPose(index, beats.length, progress, frontLoaded);
      beat.style.opacity = String(line.opacity);
      beat.style.transform = "translate3d(0, " + line.y + "px, 0)";
      if (line.opacity > bestOpacity) {
        bestOpacity = line.opacity;
        best = index;
      }
    });
    beats.forEach(function (beat) {
      var index = Number(beat.getAttribute("data-sf-beat") || 0);
      var active = index === best;
      beat.dataset.active = active ? "true" : "false";
      beat.style.pointerEvents = active ? "auto" : "none";
      if (active) beat.removeAttribute("aria-hidden");
      else beat.setAttribute("aria-hidden", "true");
    });
    var motion = chapter.querySelector(".sf-photo");
    if (motion && chapter.dataset.kind === "orb") {
      motion.style.transform = "translate(-50%, -46%) scale(" + (1.08 - progress * 0.06) + ")";
    }
  }

  function boot() {
    var root = document.querySelector("[data-secret-film]");
    if (!root) return;
    var media = window.matchMedia("(prefers-reduced-motion: reduce)");
    var frame = 0;
    var touching = false;
    var html = document.documentElement;
    document.body.style.display = "block";
    html.style.height = "auto";

    function markDriver() {
      var driver = media.matches ? "reduced" : "js";
      root.dataset.sfDriver = driver;
      html.dataset.sfDriver = driver;
      html.dataset.sfTimeline = "off";
    }

    function paint() {
      markDriver();
      root.querySelectorAll("[data-sf-chapter]").forEach(function (chapter) {
        var stage = chapter.querySelector(".sf-stage");
        if (!stage) return;
        if (media.matches) {
          paintChapter(chapter, 0.58);
          chapter.querySelectorAll("[data-sf-beat]").forEach(function (beat) {
            beat.style.opacity = "";
            beat.style.transform = "";
            beat.style.pointerEvents = "";
            beat.removeAttribute("aria-hidden");
            beat.dataset.active = "true";
          });
          var photo = chapter.querySelector(".sf-photo");
          if (photo && chapter.dataset.kind === "orb") photo.style.transform = "";
          return;
        }
        var viewport = stage.offsetHeight || window.innerHeight;
        var scrollable = Math.max(chapter.offsetHeight - viewport, 1);
        var top = chapter.getBoundingClientRect().top;
        var scrolled = clamp(-top, 0, scrollable);
        paintChapter(chapter, scrolled / scrollable);
      });
    }

    function schedule() {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(paint);
    }

    function followTouch() {
      paint();
      if (touching) frame = requestAnimationFrame(followTouch);
    }

    function onTouchStart() {
      touching = true;
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(followTouch);
    }

    function onTouchEnd() {
      touching = false;
      schedule();
    }

    markDriver();
    paint();
    window.addEventListener("scroll", schedule, { passive: true });
    document.addEventListener("scroll", schedule, { passive: true, capture: true });
    window.addEventListener("resize", schedule);
    if (window.visualViewport) {
      window.visualViewport.addEventListener("scroll", schedule);
      window.visualViewport.addEventListener("resize", schedule);
    }
    window.addEventListener("touchstart", onTouchStart, { passive: true });
    window.addEventListener("touchend", onTouchEnd, { passive: true });
    window.addEventListener("touchcancel", onTouchEnd, { passive: true });
    if (media.addEventListener) media.addEventListener("change", schedule);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }
})();
