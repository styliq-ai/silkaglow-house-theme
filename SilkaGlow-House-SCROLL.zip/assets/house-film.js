/* Pinned house film. Native scroll only.
   Desktop browsers that implement animation-timeline: view() may use CSS.
   iPhone must not: Safari can report view() support and then leave the
   film on the first line. Scroll progress in JS drives iPhone motion. */
(function () {
  function iphone() {
    return /iPhone|iPod/.test(navigator.userAgent || "");
  }
  var BEATS = 4;
  var HEIGHT_IN_VH = BEATS + 1;
  var STICKY_START = 1 / (HEIGHT_IN_VH + 1);
  var STICKY_END = HEIGHT_IN_VH / (HEIGHT_IN_VH + 1);

  function clamp01(value) {
    return Math.min(1, Math.max(0, value));
  }

  function mix(from, to, amount) {
    return from + (to - from) * amount;
  }

  function coverRange(index) {
    var span = (STICKY_END - STICKY_START) / BEATS;
    var overlap = span * 0.1;
    var from = Math.max(STICKY_START, STICKY_START + index * span - (index === 0 ? 0 : overlap));
    var to = Math.min(STICKY_END, STICKY_START + (index + 1) * span + (index === BEATS - 1 ? 0 : overlap));
    return [from, to];
  }

  function pinnedRange(index) {
    var range = coverRange(index);
    var span = STICKY_END - STICKY_START;
    return [(range[0] - STICKY_START) / span, (range[1] - STICKY_START) / span];
  }

  function beatRole(chapterIndex, beatIndex) {
    if (beatIndex === BEATS - 1) return "last";
    if (chapterIndex === 0 && beatIndex === 0) return "rest";
    return "rise";
  }

  function sample(role, local) {
    if (role === "rest") {
      if (local <= 0.7) return { opacity: 1, y: 0, scale: 1 };
      if (local >= 1) return { opacity: 0, y: -4, scale: 1.03 };
      var restAmount = clamp01((local - 0.7) / 0.3);
      return { opacity: 1 - restAmount, y: mix(0, -4, restAmount), scale: mix(1, 1.03, restAmount) };
    }
    if (role === "last") {
      if (local <= 0) return { opacity: 0, y: 4.5, scale: 0.96 };
      if (local >= 0.2) return { opacity: 1, y: 0, scale: 1 };
      var lastAmount = clamp01(local / 0.2);
      return { opacity: lastAmount, y: mix(4.5, 0, lastAmount), scale: mix(0.96, 1, lastAmount) };
    }
    if (local <= 0) return { opacity: 0, y: 4.5, scale: 0.96 };
    if (local >= 1) return { opacity: 0, y: -4, scale: 1.03 };
    if (local < 0.18) {
      var inAmount = local / 0.18;
      return { opacity: inAmount, y: mix(4.5, 0, inAmount), scale: mix(0.96, 1, inAmount) };
    }
    if (local < 0.78) return { opacity: 1, y: 0, scale: 1 };
    var outAmount = (local - 0.78) / 0.22;
    return { opacity: 1 - outAmount, y: mix(0, -4, outAmount), scale: mix(1, 1.03, outAmount) };
  }

  function clearInline() {
    document.querySelectorAll("[data-film-beat], .film-visual-motion").forEach(function (node) {
      node.style.opacity = "";
      node.style.transform = "";
      node.style.pointerEvents = "";
    });
  }

  function bootFilm() {
    if (!document.querySelector("[data-film-chapter]")) return;
    var media = window.matchMedia("(prefers-reduced-motion: reduce)");
    var frame = 0;
    var stopScroll = function () {};

    function startFallback() {
      document.documentElement.classList.add("film-js");
      document.body.style.display = "block";
      function update() {
        document.querySelectorAll("[data-film-chapter]").forEach(function (chapter) {
          var stage = chapter.querySelector(".film-stage");
          if (!stage) return;
          var viewport = stage.offsetHeight || window.innerHeight;
          var scrollable = Math.max(chapter.offsetHeight - viewport, 0);
          var scrolled = Math.min(Math.max(-chapter.getBoundingClientRect().top, 0), scrollable);
          var progress = scrollable > 0 ? scrolled / scrollable : 0;
          var chapterIndex = Number(chapter.dataset.filmIndex || 0);
          chapter.querySelectorAll("[data-film-beat]").forEach(function (beat) {
            var beatIndex = Number(beat.getAttribute("data-film-beat") || 0);
            var range = pinnedRange(beatIndex);
            var local = (progress - range[0]) / (range[1] - range[0]);
            var pose = sample(beatRole(chapterIndex, beatIndex), local);
            beat.style.opacity = String(pose.opacity);
            beat.style.transform = "translate3d(0, " + pose.y + "vh, 0) scale(" + pose.scale + ")";
            beat.style.pointerEvents = pose.opacity > 0.45 ? "auto" : "none";
          });
          var motion = chapter.querySelector(".film-visual-motion");
          if (motion) motion.style.transform = "scale(" + mix(0.94, 1.04, progress) + ")";
        });
      }
      function onScroll() {
        cancelAnimationFrame(frame);
        frame = requestAnimationFrame(update);
      }
      update();
      window.addEventListener("scroll", onScroll, { passive: true });
      window.addEventListener("resize", onScroll);
      return function () {
        cancelAnimationFrame(frame);
        window.removeEventListener("scroll", onScroll);
        window.removeEventListener("resize", onScroll);
        document.documentElement.classList.remove("film-js");
        clearInline();
      };
    }

    function apply() {
      stopScroll();
      stopScroll = function () {};
      clearInline();
      if (media.matches) {
        document.documentElement.classList.remove("film-js");
        document.documentElement.dataset.filmDriver = "reduced";
        return;
      }
      if (!iphone() && window.CSS && CSS.supports("animation-timeline: view()")) {
        document.documentElement.classList.remove("film-js");
        document.documentElement.dataset.filmDriver = "css";
        return;
      }
      document.documentElement.dataset.filmDriver = "js";
      stopScroll = startFallback();
    }

    apply();
    if (media.addEventListener) media.addEventListener("change", apply);
  }

  function bootCart() {
    document.querySelectorAll("[data-add-patches]").forEach(function (button) {
      button.addEventListener("click", function () {
        var variantId = button.getAttribute("data-variant-id");
        var root = button.closest("[data-house-film]");
        var endpoint = (root && root.getAttribute("data-cart-add")) || "/cart/add.js";
        var cartJs = (root && root.getAttribute("data-cart-js")) || "/cart.js";
        var status = button.parentElement && button.parentElement.querySelector("[data-cart-status]");
        if (!variantId) {
          var href = button.getAttribute("data-product-url");
          if (href) window.location.href = href;
          return;
        }
        button.disabled = true;
        fetch(endpoint, {
          method: "POST",
          headers: { "Content-Type": "application/json", Accept: "application/json" },
          body: JSON.stringify({ id: Number(variantId), quantity: 1 })
        })
          .then(function (response) {
            if (!response.ok) throw new Error("cart");
            return response.json();
          })
          .then(function () {
            return fetch(cartJs, { headers: { Accept: "application/json" } });
          })
          .then(function (response) {
            return response.json();
          })
          .then(function (cart) {
            document.querySelectorAll("[data-cart-count]").forEach(function (node) {
              node.textContent = cart.item_count > 0 ? " (" + cart.item_count + ")" : "";
            });
            if (status) {
              status.hidden = false;
              status.textContent = "Added. The opening will not follow you into the cart.";
            }
          })
          .catch(function () {
            if (status) {
              status.hidden = false;
              status.textContent = "The cart did not update. Open the patches and try again.";
            }
          })
          .finally(function () {
            button.disabled = false;
          });
      });
    });
  }

  function boot() {
    bootFilm();
    bootCart();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }
})();
